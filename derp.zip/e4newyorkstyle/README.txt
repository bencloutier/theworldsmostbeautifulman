The PGN file can be opened with ANY PGN reader software.
Some examples are Chess.com, Lichess, Chessbase, Chess Viewer, HIARCS, ChessTempo, and others on the internet.
